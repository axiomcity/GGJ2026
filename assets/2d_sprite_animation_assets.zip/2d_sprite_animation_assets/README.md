# 2D sprite animation assets

Used by the "2D sprite animation" tutorial:

https://docs.godotengine.org/en/latest/tutorials/2d/2d_sprite_animation.html
